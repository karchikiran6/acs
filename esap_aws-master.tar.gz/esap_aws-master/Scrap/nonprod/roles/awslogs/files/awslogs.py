import os

# Settting up proxy environmental variables

print "Setting up enviornmental variables for proxy"
os.putenv("http_proxy", "http://proxy.ebiz.verizon.com:80")
os.putenv("https_proxy", "http://proxy.ebiz.verizon.com:80")
os.putenv("NO_PROXY", "169.254.169.254")


# Downloding awslogs-agent

print "Downloading awslogs-agent"
os.system("curl https://s3.amazonaws.com/aws-cloudwatch/downloads/latest/awslogs-agent-setup.py -O")
print "Installing awslogs-agent"
os.system("python awslogs-agent-setup.py --region us-east-1 --configfile /tmp/awslogs.conf  --http-proxy http://proxy.ebiz.verizon.com:80 --https-proxy http://proxy.ebiz.verizon.com:80 --no-proxy 169.254.169.254 --non-interactive")