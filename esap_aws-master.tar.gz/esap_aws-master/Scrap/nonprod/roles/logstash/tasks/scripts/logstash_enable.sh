#!/bin/sh
/usr/bin/systemctl enable logstash