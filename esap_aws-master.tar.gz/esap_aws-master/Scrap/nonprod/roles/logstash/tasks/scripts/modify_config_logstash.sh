#!/bin/sh
mkdir -p /data/sincedb
chmod 777 /data/sincedb
chmod 775 /var/log/messages
chmod 775 /var/log/dmesg
chmod 775 /var/log/auth.log
chmod 775 /var/log/boot.log
chmod 775 /var/log/cron.log
chmod 775 /var/log/kern.log
touch /data/sincedb/registry
cat << EOF > /etc/logstash/conf.d/config.json
input {
   file {
        path =>  ["/var/log/messages"]
        start_position => "beginning"
        ignore_older => "8640000"
        sincedb_path => "/data/sincedb/registry"
        type => "SystemLog"
  }
   file {
        path =>  ["/var/log/dmesg"]
        start_position => "beginning"
        ignore_older => "8640000"
        sincedb_path => "/data/sincedb/registry"
        type => "SystemLog"
  }
   file {
       path =>  ["/apps/opt/weblogic/config/apc/apc_srv_01.stdout.log"]
       start_position => "beginning"
       ignore_older => "8640000"
       sincedb_path => "/data/sincedb/registry"
       type => "ApplicationLog"
 }
   file {
       path =>  ["${1}"]
       start_position => "beginning"
       ignore_older => "8640000"
       sincedb_path => "/data/sincedb/registry"
       type => "ApplicationLog"
 }
   file {
       path =>  ["/var/log/auth.log"]
       start_position => "beginning"
       ignore_older => "8640000"
       sincedb_path => "/data/sincedb/registry"
       type => "SystemLog"
 }
   file {
       path =>  ["/var/log/boot.log"]
       start_position => "beginning"
       ignore_older => "8640000"
       sincedb_path => "/data/sincedb/registry"
       type => "SystemLog"
 }
   file {
       path =>  ["/var/log/cron.log"]
       start_position => "beginning"
       ignore_older => "8640000"
       sincedb_path => "/data/sincedb/registry"
       type => "SystemLog"
 }
   file {
       path =>  ["/var/log/kern.log"]
       start_position => "beginning"
       ignore_older => "8640000"
       sincedb_path => "/data/sincedb/registry"
       type => "SystemLog"
 }
}

output {
   s3 {
     region => "us-east-1"
     bucket => "$3"
     size_file => 2048
     time_file => 5
    }
}
EOF