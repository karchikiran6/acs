#!/usr/bin/python
from subprocess import call
call(['bash', '/tmp/logstash_enable.sh'])