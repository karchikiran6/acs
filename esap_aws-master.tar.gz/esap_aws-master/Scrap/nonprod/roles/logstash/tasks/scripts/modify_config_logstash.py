#!/usr/bin/python
import sys
Logpath=sys.argv[1]
Topic=sys.argv[2]
from subprocess import call
call(['bash', '/tmp/modify_config_logstash.sh', Logpath, Topic])