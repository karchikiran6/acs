#!/bin/ksh
. /dataserver/proj/proj-setup

# Grep the top line of tomcat time
#Example output
#tomcat 27024     1  3 16:54 ?        00:00:21 /apps/opt/jdk170_111_64/bin/java -Djava.util.logging.config.file=/apps/opt/ASF-Apache/domains/tomcat/ESAPFDV/conf/logging.properties -Djava.util.logging.manager=org.apache.juli.ClassLoaderLogManager -DPROJ_ETC=/dataserver/proj/tomcat_etc -Xms256m -Xmx1024m -Djdk.tls.ephemeralDHKeySize=2048 -classpath /apps/opt/ASF-Apache/domains/tomcat/ESAPFDV/bin/bootstrap.jar:/apps/opt/ASF-Apache/domains/tomcat/ESAPFDV/webapps/ROOT/WEB-INF/lib/ojdbc6.jar:/apps/opt/ASF-Apache/domains/tomcat/ESAPFDV/webapps/ROOT/WEB-INF/lib/tomcat-dbcp-8.0.0-rc1.jar:/apps/opt/ASF-Apache/domains/tomcat/ESAPFDV/webapps/ROOT/WEB-INF/lib/commons-dbcp-eap6.jar:/apps/opt/ASF-Apache/domains/tomcat/ESAPFDV/bin/tomcat-juli.jar -Dcatalina.base=/apps/opt/ASF-Apache/domains/tomcat/ESAPFDV -Dcatalina.home=/apps/opt/ASF-Apache/domains/tomcat/ESAPFDV -Djava.io.tmpdir=/apps/opt/ASF-Apache/domains/tomcat/ESAPFDV/temp org.apache.catalina.startup.Bootstrap

TOMCAT_SVR_OUTPUT=$(ps -ef | grep tomcat.*[0-9][0-9][:][0-9][0-9][[:space:]].*catalina.startup.Bootstrap -o | egrep -v grep )
TOMCAT_SVR_TIME=$(echo $TOMCAT_SVR_OUTPUT | awk -F" " '{print $5}')
TOMCAT_SVR_HOUR=$(echo $TOMCAT_SVR_TIME | awk -F":" '{print $1}')
TOMCAT_SVR_MIN=$(echo $TOMCAT_SVR_TIME| awk -F":" '{print $2}')
TOMCAT_SVR_PID=$(echo $TOMCAT_SVR_OUTPUT| awk -F" " '{print $2}')
# Grep the most recent error
#Example output
#[Mon Jan 28 12:47:26.103313 2019] [proxy_http:error] [pid 23731:tid 139879881209600] (70007)The timeout specified has expired: [client 144.8.230.184:61616] AH01102: error reading status line from remote server localhost:8080, referer: https://esap-awsfdvs-prod.vpc.verizon.com/esap-web/SiteMapServlet?command=MapFrame

#TOMCAT_ERROR_OUTPUT=$(tac /apps/opt/ASF-Apache/domains/httpd/ESAPFDV/logs/error_log | grep -m 1 "The timeout specified has expired:")

TOMCAT_ERROR_OUTPUT=$(tac /apps/opt/ASF-Apache/domains/httpd/ESAPFDV/logs/error_log | grep -m 1 -e "The timeout specified has expired" -e "Internal error:" -e "Connection refused:" )

TOMCAT_ERROR_TIME=$(echo $TOMCAT_ERROR_OUTPUT | awk -F" " '{print $4}')
TOMCAT_ERROR_HOUR=$(echo $TOMCAT_ERROR_TIME | awk -F":" '{print $1}')
TOMCAT_ERROR_MIN=$(echo $TOMCAT_ERROR_TIME| awk -F":" '{print $2}')

#Debug Printing
echo "----------------------------------------------------------------------------------"
echo "TOMCAT_SVR_OUTPUT = $TOMCAT_SVR_OUTPUT"
echo "----------------------------------------------------------------------------------"
echo "TOMCAT_SVR_TIME = $TOMCAT_SVR_TIME"
echo "TOMCAT_SVR_HOUR = $TOMCAT_SVR_HOUR"
echo "TOMCAT_SVR_MIN = $TOMCAT_SVR_MIN"
echo "TOMCAT_SVR_PID = $TOMCAT_SVR_PID"

echo "----------------------------------------------------------------------------------"
echo "TOMCAT_ERROR_OUTPUT = $TOMCAT_ERROR_OUTPUT"
echo "----------------------------------------------------------------------------------"
echo "TOMCAT_ERROR_TIME = $TOMCAT_ERROR_TIME"
echo "TOMCAT_ERROR_HOUR = $TOMCAT_ERROR_HOUR"
echo "TOMCAT_ERROR_MIN = $TOMCAT_ERROR_MIN"

# Compare the two time stamps
# If tomcat time < recent error, bounce server
if [[ $TOMCAT_SVR_HOUR =~ ([A-Z]|[a-z]) || $TOMCAT_ERROR_HOUR =~ ([A-Z]|[a-z]) || $TOMCAT_SVR_MIN =~ ([A-Z]|[a-z]) || $TOMCAT_ERROR_MIN =~ ([A-Z]|[a-z]) ]]; 
then
echo "One of the comparison values contains alpha characters, so not executing";
elif [ -z "$TOMCAT_SVR_HOUR" -o -z "$TOMCAT_SVR_MIN" -o -z "$TOMCAT_ERROR_HOUR" -o -z "$TOMCAT_ERROR_MIN" ]
then
echo "One of the comparison values were null, so not executing."
elif [ "$TOMCAT_SVR_HOUR" -lt "$TOMCAT_ERROR_HOUR" -o "TOMCAT_SVR_HOUR" -eq "TOMCAT_ERROR_HOUR" -a "$TOMCAT_SVR_MIN" -lt "$TOMCAT_ERROR_MIN" ]
then
echo "Match found starting Tomcat condition:";
echo "Killing Tomcat";
#kill -KILL $TOMCAT_SVR_PID
#/apps/opt/ASF-Apache/scripts/tomcat/TomcatHealthCheck.sh
#/apps/opt/ASF-Apache/scripts/tomcat/TomcatForceStop.sh -p $TOMCAT_SVR_PID
# First get the thread dumps
echo "INFO: Starting to collect 5 thread dumps against the process $TOMCAT_SVR_PID"
for i in 1 2 3 4 5
do
        echo "INFO: Sending thread dump number $i to Tomcat pid# $TOMCAT_SVR_PID"
        kill -3 $TOMCAT_SVR_PID
        sleep 5
done
echo "INFO: Finished collecting thread dumps..."

# Now, send the pid a kill -9 to bring it down
echo "INFO: Sending a kill -9 signal to Tomcat pid# $TOMCAT_SVR_PID"
kill -9 $TOMCAT_SVR_PID 
export PROJ_ETC=/dataserver/proj/tomcat_etc;/apps/opt/ASF-Apache/scripts/tomcat/TomcatStartAllDomains.sh
else
echo "Tomcat server is more recent than error, so not deploying."
fi;

