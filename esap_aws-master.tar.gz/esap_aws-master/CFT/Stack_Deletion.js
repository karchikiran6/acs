{
   "AWSTemplateFormatVersion":"2010-09-09",
   "Description":"",
   "Parameters" : {    
    "AWS_REGION" : {      
      "Type" : "String"
    }    ,
    "StackName" : {
      "Type" : "String"
    }   
  },
   "cloudformation" : {
    "stack_name": { "Ref" : "StackName" },
    "region": { "Ref" : "AWS_REGION" },
	"state": "absent"
  }
}