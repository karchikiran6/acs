
#!/usr/bin/bash
set -x

ENV=$1
Source=$2
S3BucketPath=vaclogs/

echo Starting the Job at $(date +"%T")

if [[ $ENV == "NONPROD" ]] ;then
        export http_proxy=http://proxy.ebiz.verizon.com:80
        export https_proxy=http://proxy.ebiz.verizon.com:80
        export no_proxy="169.254.169.254, .verizon.com"
        export KMS_KEY=arn:aws:kms:us-east-1:084309170734:key/a4e07059-0e28-4f82-b746-6ca6d3e1ed5d
        export S3_BUCKET=s3://vz-app-nts-dqxv-non-prod-weblogs-us-east-1-s3bucket

else
        export http_proxy=http://vzproxy.verizon.com:80
        export https_proxy=http://vzproxy.verizon.com:80
        export no_proxy="169.254.169.254, .verizon.com"
        export KMS_KEY=arn:aws:kms:us-east-1:805058090157:key/61cfdb57-7296-4f54-9f9a-b77a9376f9b7
        export S3_BUCKET=s3://vz-app-nts-pbxv-prod-esap-us-east-1-s3bucket
fi

export EC2_INSTANCE_ID=$(curl -s http://169.254.169.254/latest/meta-data/instance-id)
export EC2_REGION=$(curl -s http://169.254.169.254/latest/dynamic/instance-identity/document | grep region | awk -F\" '{print $4}')

/usr/local/bin/aws s3 sync  --sse aws:kms --sse-kms-key-id $KMS_KEY   /dataserver/logs/cem/ $S3_BUCKET/$S3BucketPath

echo Ending the Job at $(date +"%T")

