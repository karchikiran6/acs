#!/bin/sh
cd /apps/etc/SSI/
oldip=`ls | grep - | head -1 | cut -d "." -f2`
newip=`hostname -s`
sourceip=`ls | grep ip | head -1 | cut -d "." -f2 | cut -d "-" -f2-5 | sed 's/-/./g'`
destip=`hostname -i`
mv host.${oldip}.ebiz.verizon.com.sso.ssi host.${newip}.ebiz.verizon.com.sso.ssi
mv host.${oldip}.ebiz.verizon.com.jbapache.LQP host.${newip}.ebiz.verizon.com.jbapache.LQP
mv host.${oldip}.ebiz.verizon.com.jbapache.LQP.include host.${newip}.ebiz.verizon.com.jbapache.LQP.include
sed 's/'"$oldip"'/'"$newip"'/g' < host.${newip}.ebiz.verizon.com.sso.ssi > host.${newip}.ebiz.verizon.com.sso.ssi_bkp
mv -f host.${newip}.ebiz.verizon.com.sso.ssi_bkp host.${newip}.ebiz.verizon.com.sso.ssi     
sed 's/'"$oldip"'/'"$newip"'/g' < host.${newip}.ebiz.verizon.com.jbapache.LQP > host.${newip}.ebiz.verizon.com.jbapache.LQP_bkp
mv -f host.${newip}.ebiz.verizon.com.jbapache.LQP_bkp host.${newip}.ebiz.verizon.com.jbapache.LQP
sed 's/'"$oldip"'/'"$newip"'/g' < host.${newip}.ebiz.verizon.com.jbapache.LQP.include > host.${newip}.ebiz.verizon.com.jbapache.LQP.include_bkp
mv -f host.${newip}.ebiz.verizon.com.jbapache.LQP.include_bkp host.${newip}.ebiz.verizon.com.jbapache.LQP.include
sleep 10
/apps/opt/jboss-ews/scripts/JBApacheAdmin.sh -A START -d LQP

