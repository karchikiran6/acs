#!/usr/bin/python
with open('/opt/logstash/bin/logstash', 'a') as file:
    file.write('export JAVA_HOME=/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.91-2.6.2.3.el7.x86_64/jre\n')
    file.write('export PATH=$JAVA_HOME/bin:$PATH\n')