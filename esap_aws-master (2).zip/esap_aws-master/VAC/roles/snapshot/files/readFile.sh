#!/bin/bash
set -x
nowdate="$(date +"%m-%d-%Y")"
TNOW="$(date +"%T")"
printf "$TNOW"
printf " Last ESAP run time $LAST_ESAP_VAC_REPORT_RUN_TIME"
printf "ESAP - VAC order  process report started $TNOW"
printf "Last ESAP VAC run at $TNOW"
#linenumber=$(grep -i -n  /dataserver/logs/cem/esap_log.log |head -1 |cut -d ':' -f1)
printf "Starting from line $linenumber"
templogs="/dataserver/logs/cem/esap_log.log"
#/usr/xpg4/bin/awk -v linest=$linenumber 'NR>=linest' /dataserver/logs/cem/esap_log.log > $templogs
s2e=$(grep -wc "Message From QueueManager: <IVAPP.PRD.S2E>" $templogs)
s2f=$(grep -wc "Message From QueueManager: <IVAPP.PRD.S2F>" $templogs)
s1e=$(grep -wc "Message From QueueManager: <IVAPP.PRD.STH1E>" $templogs)
s1f=$(grep -wc "Message From QueueManager: <IVAPP.PRD.STH1F>" $templogs)
n1a=$(grep -wc "Message From QueueManager: <IVAPP.PRD.N1A>" $templogs)
n1b=$(grep -wc "Message From QueueManager: <IVAPP.PRD.N1B>" $templogs)
rsps2=$(grep -wc "Opened Write Queue name : <VACQM.QR.IVAPPS2>" $templogs)
rsps1=$(grep -wc "Opened Write Queue name : <VACQM.QR.IVAPPS1>" $templogs)
rspn=$(grep -wc "Opened Write Queue name : <VACQM.QR.IVAPPN1>" $templogs)
vacreq=$(grep -wc "Opened Write Queue name : <VACQM.QL.CMD>" $templogs)
vacrsp=$(grep -wc "Got MQMessage: {<SOTransRsp>" $templogs)
TFNOVERAL="/tmp/vacmail1.txt"
echo "                          ESAP_VAC ALERT DETAILS                           "  > $TFNOVERAL
echo "---------------------------------------------------------------------------"  >> $TFNOVERAL
echo " " >> $TFNOVERAL
echo "                IVAPP  -  ESAP_VAC REQUEST COUNT                           " >> $TFNOVERAL
echo "---------------------------------------------------------------------------"  >> $TFNOVERAL
echo "    NORTH           ||  SOUTH1                || SOUTH2               " >> $TFNOVERAL
echo "---------------------------------------------------------------------------"  >> $TFNOVERAL
echo " NORTH1C | NORTH1D  || SOUTH1E   | SOUTH1F    || SOUTH2E   | SOUTH2F  " >> $TFNOVERAL
echo "---------------------------------------------------------------------------"  >> $TFNOVERAL
echo " $n1a    | $n1b      || $s1e      | $s1f       || $s2e      |  $s2f    " >> $TFNOVERAL
echo " " >> $TFNOVERAL
echo " " >> $TFNOVERAL
echo " " >> $TFNOVERAL
echo "                ESAP_VAC  -  IVAPP RESPONSE COUNT                          " >> $TFNOVERAL
echo "---------------------------------------------------------------------------"  >> $TFNOVERAL
echo "    NORTH           ||  SOUTH1                || SOUTH2               " >> $TFNOVERAL
echo "---------------------------------------------------------------------------"  >> $TFNOVERAL
echo "    $rspn           ||  $rsps1                || $rsps2               " >> $TFNOVERAL
echo " " >> $TFNOVERAL
echo " " >> $TFNOVERAL
echo " " >> $TFNOVERAL
echo "                ESAP_VAC  -  VM COUNT                                    " >> $TFNOVERAL
echo "---------------------------------------------------------------------------"  >> $TFNOVERAL
echo "        REQUEST                  ||              RESPONSE             " >> $TFNOVERAL
echo "---------------------------------------------------------------------------"  >> $TFNOVERAL
echo "       $vacreq                   ||              $vacrsp              " >> $TFNOVERAL
#cat /tmp/vacmail1.txt | /usr/bin/mailx -s "ESAP VAC Order Processing Report date $nowdate" salt@one.verizon.com esap-dev-vzt@one.verizon.com esap_alerts@one.verizon.com karthik.varadarajulu@one.verizon.com
SUBJECT="ESAP VAC Order Processing Report date $nowdate"
receipents="salt@one.verizon.com esap-dev-vzt@one.verizon.com esap_alerts@one.verizon.com karthik.varadarajulu@one.verizon.com"
/usr/sbin/sendmail -F "ESAP VAC" $receipents <<EOF
To: $receipents
Subject:${SUBJECT}
Content-Type: text/html; charset="utf-8"
X-Priority: 1 (Highest)
X-MSMail-Priority: High
<html>
<head>
<meta charset="ISO-8859-1">
<title> ESAP VAC Order Processing Report </title>
</head>
<body>
<pre>
`cat /tmp/vacmail1.txt`
</pre>
</body>
</html>
EOF
#rm /tmp/vacmail1.txt

